---
layout: post
title: 我的书单
permalink: /books/
---

* content
{:toc}


2016书单
-----------------------------------------------------------------

+ 《Think in java 4th》
+ 《鸟哥的Linux私房菜基础学习篇-第三版》
+ 《重构》
+ 《Getting real》
+ 《深入JVM虚拟机》
+ 《Head first设计模式》
+ 《算法(第四版)》
+ 《Maven实战》
+ 《HTTP协议详解》
+ 《TCP/IP协议详解-卷一》
+ 《阿弥陀佛么么哒》
